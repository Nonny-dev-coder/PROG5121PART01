import java.util.Scanner;

/**
 * Simple console chat application that demonstrates user registration and login.
 * The application reads user details, validates username, password and cellphone,
 * registers the user and then prompts for login credentials to verify access.
 *
 * Compact and educational demo.
 *
 * @author RC_Student_lab (fixed and enhanced)
 /*
 
 */

/**
 *
 * @author RC_Student_lab
 */
public class ChattAppJava {
     // Single shared reference to the currently registered user for this demo app.
    private static User user = null;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("==== Create New Account ====");

            // Capture basic user identity information
            System.out.print("Enter First Name: ");
            String firstName = sc.nextLine().trim();
            System.out.print("Enter Last Name (surname): ");
            String lastName = sc.nextLine().trim();

            // Capture and validate username
            String username;
            do {
                System.out.print("Enter username (must contain an underscore and be no more than 5 characters): ");
                username = sc.nextLine().trim();
                if (checkUsername(username)) {
                    System.out.println("Username successfully captured.");
                    break;
                }
                System.out.println("Invalid username format. It must contain an underscore and be no more than 5 characters long.");
            } while (true);

            // Capture and validate password
            String password;
            do {
                System.out.print("Enter password (min 8 chars, at least one uppercase, one digit, one special char): ");
                password = sc.nextLine();
                if (checkPasswordComplexity(password)) {
                    System.out.println("Password successfully captured.");
                    break;
                }
                System.out.println("Password is not strong enough. It must be at least 8 characters long, contain a capital letter, a number, and a special character.");
            } while (true);

            // Capture and validate cellphone number
            String cellphoneNumber;
            do {
                System.out.print("Enter cellphone number (include international code, e.g. +27..., 0027... or local format): ");
                cellphoneNumber = sc.nextLine().trim();
                if (validateCellphoneNumber(cellphoneNumber)) {
                    System.out.println("Cellphone number successfully captured.");
                    break;
                }
                System.out.println("Invalid cellphone number format. Please include country code correctly and only digits (optionally '+' or '00' prefix).");
            } while (true);

            // Register the user (store into shared 'user' reference)
            registerUser(firstName, lastName, username, password, cellphoneNumber);

            // Login phase
            System.out.println("\n==== Login ====");
            System.out.print("Username: ");
            String loginUsername = sc.nextLine().trim();
            System.out.print("Password: ");
            String loginPassword = sc.nextLine();

            // Check credentials and print a user-facing message
            String loginMessage = returnLoginStatus(loginUsername, loginPassword);
            System.out.println(loginMessage);

        } finally {
            // Close the scanner to free the resource
            sc.close();
        }
    }

    /**
     * Validate username rules:
     * - Must contain an underscore
     * - Must be at most 5 characters long
     */
    public static boolean checkUsername(String username) {
        if (username == null) {
            return false;
        }
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Validate password complexity:
     * - At least 8 characters
     * - At least one uppercase letter
     * - At least one digit
     * - At least one special character (non-letter and non-digit)
     */
    public static boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;

        // Iterate through all characters to determine character classes present
        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);
            if (Character.isUpperCase(ch)) {
                hasCapital = true;
            }
            if (Character.isDigit(ch)) {
                hasDigit = true;
            }
            if (!Character.isLetterOrDigit(ch)) {
                hasSpecialChar = true;
            }

            // small early-exit optimization
            if (hasCapital && hasDigit && hasSpecialChar) {
                break;
            }
        }

        return hasCapital && hasDigit && hasSpecialChar;
    }

    /**
     * Basic cellphone validation:
     * Accepts:
     * - +<digits> (e.g. +27123456789)
     * - 00<digits> (e.g. 0027123456789)
     * - local numeric form (digits only), length between 7 and 15
     */
    public static boolean validateCellphoneNumber(String cellphone) {
        if (cellphone == null) {
            return false;
        }
        String normalized = cellphone.replaceAll("\\s+", ""); // remove spaces

        if (normalized.startsWith("+")) {
            String rest = normalized.substring(1);
            return rest.matches("\\d{7,15}");
        } else if (normalized.startsWith("00")) {
            String rest = normalized.substring(2);
            return rest.matches("\\d{7,15}");
        } else {
            // local format — ensure digits only and reasonable length
            return normalized.matches("\\d{7,15}");
        }
    }

    /**
     * Store the single demo user in-memory.
     */
    public static void registerUser(String firstName, String lastName, String username, String password, String cellphone) {
        user = new User(firstName, lastName, username, password, cellphone);
    }

    /**
     * Return a user-friendly login status based on given credentials.
     */
    public static String returnLoginStatus(String usernameAttempt, String passwordAttempt) {
        if (user == null) {
            return "No user registered in system.";
        }
        if (user.getUsername().equals(usernameAttempt) && user.getPassword().equals(passwordAttempt)) {
            return "Login successful. Welcome, " + user.getFirstName() + "!";
        } else {
            return "Login failed. Invalid username or password.";
        }
    }

    /**
     * Simple user holder class.
     */
    static class User {
        private final String firstName;
        private final String lastName;
        private final String username;
        private final String password;
        private final String cellphoneNumber;

        // Constructor - store values
        public User(String firstName, String lastName, String username, String password, String cellphoneNumber) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.cellphoneNumber = cellphoneNumber;
        }

        // Basic getters
        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }

        public String getCellphoneNumber() {
            return cellphoneNumber;
        }
    }
}
 