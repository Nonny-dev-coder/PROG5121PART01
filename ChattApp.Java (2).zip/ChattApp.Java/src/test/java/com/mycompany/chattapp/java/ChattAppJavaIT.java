/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chattapp.java;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class ChattAppJavaIT {
    
    public ChattAppJavaIT() {
    }

    @Test
    public void testMain() {
    }

    @Test
    public void testCheckUsername() {
    }

    @Test
    public void testCheckPasswordComplexity() {
    }

    @Test
    public void testValidateCellphoneNumber() {
    }

    @Test
    public void testRegisterUser() {
    }

    @Test
    public void testReturnLoginStatus() {
    }
    
}
